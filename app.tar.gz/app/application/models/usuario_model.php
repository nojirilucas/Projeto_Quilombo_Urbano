<?php
class Usuario_model extends CI_Model {

    public $table;
    public function construct()
    {
        parent::construct();
       $this->table = 'usuario';
    }

    public function salvar($usuario)
    {
        $this->db->insert($this->table,$usuario);
    }

    public function get($email,$senha)
    {
        $this->db->where('email',$email);
        $this->db->where('senha',$senha);
        return $this->db->get($this->table)->row_object();
    }
}